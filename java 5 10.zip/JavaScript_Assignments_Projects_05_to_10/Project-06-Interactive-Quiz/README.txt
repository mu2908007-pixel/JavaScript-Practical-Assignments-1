PROJECT: Interactive Quiz & Grade System

TASK
Ask 3 general-knowledge questions, add 1 point for each correct answer, then display the score and a grade or pass/fail message.

FILES
- index.html: Opens this project in your browser and loads script.js.
- script.js: Write your own JavaScript here.

STEPS
1. Read the task carefully.
2. Write the JavaScript logic yourself in script.js.
3. Save the file.
4. Open index.html in a browser.
5. If using console.log(), press F12 and open the Console tab.
6. Test more than one input, including an invalid or edge case where relevant.

REMINDER
Your assignment requires hands-on JavaScript written manually. This starter folder does not contain a completed solution.
