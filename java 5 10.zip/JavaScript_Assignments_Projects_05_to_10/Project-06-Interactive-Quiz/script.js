// Interactive Quiz & Grade System
//
// Your task:
// Ask 3 general-knowledge questions, add 1 point for each correct answer, then display the score and a grade or pass/fail message.
//
// IMPORTANT: Write the JavaScript logic yourself.
// Use the project README.txt as your checklist.

// TODO 1: Declare the variables you need.
// TODO 2: Get any required input from the user.
// TODO 3: Write the required JavaScript logic.
// TODO 4: Display the result using alert() or console.log().
// TODO 5: Test normal and edge-case inputs.
