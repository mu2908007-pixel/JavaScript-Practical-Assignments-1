PROJECT: City Finder & Search Engine

TASK
Create an array of cities. Ask the user for a city and use a for loop plus a Boolean flag to check whether it exists.

FILES
- index.html: Opens this project in your browser and loads script.js.
- script.js: Write your own JavaScript here.

STEPS
1. Read the task carefully.
2. Write the JavaScript logic yourself in script.js.
3. Save the file.
4. Open index.html in a browser.
5. If using console.log(), press F12 and open the Console tab.
6. Test more than one input, including an invalid or edge case where relevant.

REMINDER
Your assignment requires hands-on JavaScript written manually. This starter folder does not contain a completed solution.
