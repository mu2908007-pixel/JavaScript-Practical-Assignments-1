// City Finder & Search Engine
//
// Your task:
// Create an array of cities. Ask the user for a city and use a for loop plus a Boolean flag to check whether it exists.
//
// IMPORTANT: Write the JavaScript logic yourself.
// Use the project README.txt as your checklist.

// TODO 1: Declare the variables you need.
// TODO 2: Get any required input from the user.
// TODO 3: Write the required JavaScript logic.
// TODO 4: Display the result using alert() or console.log().
// TODO 5: Test normal and edge-case inputs.
