// Time-Based Greeting & Schedule Checker
//
// Your task:
// Ask the user for an hour (0–23), then use if / else if / else and comparison operators to display the correct greeting. Handle invalid hours.
//
// IMPORTANT: Write the JavaScript logic yourself.
// Use the project README.txt as your checklist.

// TODO 1: Declare the variables you need.
// TODO 2: Get any required input from the user.
// TODO 3: Write the required JavaScript logic.
// TODO 4: Display the result using alert() or console.log().
// TODO 5: Test normal and edge-case inputs.
