// Dynamic Movie / Shopping Wishlist Manager
//
// Your task:
// Start with an array of 3 items. Let the user add, remove, insert, or delete items using push, pop, shift, unshift, and splice.
//
// IMPORTANT: Write the JavaScript logic yourself.
// Use the project README.txt as your checklist.

// TODO 1: Declare the variables you need.
// TODO 2: Get any required input from the user.
// TODO 3: Write the required JavaScript logic.
// TODO 4: Display the result using alert() or console.log().
// TODO 5: Test normal and edge-case inputs.
