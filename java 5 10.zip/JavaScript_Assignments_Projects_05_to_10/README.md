# JavaScript Practical Assignments — Projects 05 to 10

This ZIP contains starter folders for Projects 05–10. Projects 01–04 are intentionally not included.

## Important assignment rule
Your assignment says that JavaScript logic must be written manually by you, without AI-generated JavaScript solutions. Therefore, each `script.js` file contains TODO instructions only—not completed solutions.

## How to use
1. Extract this ZIP.
2. Open the extracted `JavaScript_Assignments_Projects_05_to_10` folder in VS Code.
3. Open one project folder at a time.
4. Read its `README.txt`.
5. Write your own JavaScript in `script.js`.
6. Open `index.html` in a browser. Use the browser console (F12 → Console) for console output.

Each project includes:
- `index.html` — a simple page connected to its JavaScript file.
- `script.js` — an empty starter file with TODO comments.
- `README.txt` — project requirements and testing ideas.

Do not submit the TODO starter files as completed assignments. Finish and test your own JavaScript first.
